var array=[];
var length=prompt("enter required length of array");
for(var i=0;i<length;i++){
    array[i]=prompt("enter element");
}
console.log("original array:"+array);
var rev=array.reverse();
console.log("reverse array:"+rev);



