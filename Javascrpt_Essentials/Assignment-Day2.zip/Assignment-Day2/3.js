var array=[];
var length=prompt("enter required length of array");
for(var i=0;i<length;i++){
    array[i]=prompt("enter string");
}
var E=prompt("enter element");
array.forEach(function(ele)
{
   if(ele==E)
      console.log("element found");
})


