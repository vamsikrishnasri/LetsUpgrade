let minute=prompt("enter minutes");
let seconds=minute*60;
console.log(seconds);


