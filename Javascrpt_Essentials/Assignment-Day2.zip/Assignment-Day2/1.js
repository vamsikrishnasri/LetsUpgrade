let data=prompt("enter string");
let char=prompt("enter character");
for(let i=0;i<data.length;i++)
{ 
	if(data.charAt(i)==char)
		console.log("character found");
	else
		console.log("character not found");
	

}


